<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of BonusHistoryEntryOPERATIONRECALLED, left for backward compatibility
 * @see BonusHistoryEntryOPERATIONRECALLED
 */
class HistoryEntryOPERATIONRECALLED extends BonusHistoryEntryOPERATIONRECALLED
{

}
<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of GetBonusHistoryResponse, left for backward compatibility
 * @see GetBonusHistoryResponse
 */
class GetHistoryResponse
{
    /**
     * 
     *
     * @var HistoryEntry[]
     */
    protected $history;

    /**
     * 
     *
     * @var GetHistoryResponsePagination
     */
    protected $pagination;

    /**
     * 
     *
     * @return HistoryEntry[]
     */
    public function getHistory()
    {
        return $this->history;
    }

    /**
     * 
     *
     * @param HistoryEntry[] $history
     *
     * @return self
     */
    public function setHistory(array $history)
    {
        $this->history = $history;
        return $this;
    }

    /**
     * 
     *
     * @return GetHistoryResponsePagination
     */
    public function getPagination()
    {
        return $this->pagination;
    }

    /**
     * 
     *
     * @param GetHistoryResponsePagination $pagination
     *
     * @return self
     */
    public function setPagination(GetHistoryResponsePagination $pagination)
    {
        $this->pagination = $pagination;
        return $this;
    }
}
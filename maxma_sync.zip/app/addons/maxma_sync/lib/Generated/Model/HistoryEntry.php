<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of BonusHistoryEntry, left for backward compatibility
 * @see BonusHistoryEntry
 */
class HistoryEntry extends BonusHistoryEntry
{

}
<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of BonusHistoryEntryOPERATIONRECEIVED, left for backward compatibility
 * @see BonusHistoryEntryOPERATIONRECEIVED
 */
class HistoryEntryOPERATIONRECEIVED extends BonusHistoryEntryOPERATIONRECEIVED
{

}
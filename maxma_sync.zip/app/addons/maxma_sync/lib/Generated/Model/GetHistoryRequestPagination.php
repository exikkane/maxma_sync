<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of GetBonusHistoryRequestPagination, left for backward compatibility
 * @see GetBonusHistoryRequestPagination
 */
class GetHistoryRequestPagination extends GetBonusHistoryRequestPagination
{

}
<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of AppliedOffer, left for backward compatibility
 * @see AppliedOffer
 */
class CalculationResultRowOffersItem extends AppliedOffer
{

}
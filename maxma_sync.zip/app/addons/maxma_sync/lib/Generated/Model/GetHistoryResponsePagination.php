<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of GetBonusHistoryResponsePagination, left for backward compatibility
 * @see GetBonusHistoryResponsePagination
 */
class GetHistoryResponsePagination extends GetBonusHistoryResponsePagination
{

}
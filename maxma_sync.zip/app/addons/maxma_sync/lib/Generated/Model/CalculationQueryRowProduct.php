<?php

namespace CloudLoyalty\Api\Generated\Model;

/**
 * @deprecated in favour of Product, left for backward compatibility
 * @see Product
 */
class CalculationQueryRowProduct extends Product
{

}
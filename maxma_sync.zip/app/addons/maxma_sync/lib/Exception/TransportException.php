<?php

namespace CloudLoyalty\Api\Exception;

class TransportException extends \Exception
{
}
<?php

namespace CloudLoyalty\Api\Serializer;

// Represents a null value that must be serialized as JSON's null.
class NullValue {}
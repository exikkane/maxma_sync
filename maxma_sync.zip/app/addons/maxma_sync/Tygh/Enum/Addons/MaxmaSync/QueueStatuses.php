<?php

namespace Tygh\Enum\Addons\MaxmaSync;

class QueueStatuses
{
    const NEW = 'new';
    const PROCESSING = 'processing';
    const DONE = 'done';
    const ERROR = 'error';
}
